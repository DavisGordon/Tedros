create user if not exists dbUser  PASSWORD 'xpto'  ADMIN;
create schema if not exists tedros_core authorization dbUser;
create schema if not exists riosemfome authorization dbUser;
create schema if not exists solidarity authorization dbUser;

