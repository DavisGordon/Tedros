create user if not exists tdrs  PASSWORD 'xpto'  ADMIN;
create schema if not exists tedros authorization tdrs;
create schema if not exists tedros_core authorization tdrs;
create schema if not exists tedros_shared_data authorization tdrs;
create schema if not exists tedros_odonto authorization tdrs;
create schema if not exists swaha authorization tdrs;
